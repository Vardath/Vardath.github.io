# Implementation and native-interface provenance — 0.3.0

`order.vardath.go.*` registers 13 persistent defaults and one finite queued order. `vardath.go.worker` coordinates scope, staggered local discovery, reservations, serials, results, rewards and release. State lives in the real `player.entity` blackboard, keyed by ship/target; it does not attach blackboards to ship/station components. `VGO_State` manages persistent registries, genuine passenger actors, recovery and throttled activity/payment reports.

Native movement uses gates/connections through `move.generic`, undocking through `move.undock`, and `order.dock` where required. Connected unlimited range omits the maximum jump distance; jobs generally rotate sectors rather than globally scanning every frame. Tour catalogue work is cached. Direct native orders have priority. Deadlines and target invalidation defer unsuccessful work; no timeout creates a reward.

Hacking uses `vardath.go.hacker.catalogue`, `vardath.go.task.hacker`, independent `VGO_Hacker` actor/tool recovery and `ui/vgo_hacker.lua`. Native `find_room hascontrolpanel`, `find_hack_slot`, `ControlPanelInfo` and required-ware queries identify actual panels. Existing real crew walk with native `npc_move_to`, hold `pda1hand` when rendered, and must return to an actual ship room. Tool loans and returns measure inventory deltas and roll back failures. No actor is created, crew post/ownership rewritten, or actor teleported ashore. `add_actor_to_post_location` is restricted to initial materialisation aboard and after actual return.

The same native `StartControlPanelHack` used by the vanilla confirmation menu supplies panel-specific effects and native costs. It has no actor argument: player-attributed invocation after actual NPC arrival is an explicitly documented alternative, not verified NPC engine support. The call is serialized and tokenized. No whole-station hacked flag or timer success is used. The queued command uses documented `create_order default=false immediate=false override=false`; there is no invented `append` action attribute or default-order replacement. Its panel parameter uses native `type=internal`.

Payments use native reward/transfer actions only after task verification; income records contain actual observed player balance changes. Existing shared-cursor General receipts operate independently of the optional native-description callback. The ledger renderer and Protected UI are untouched. Hacking and unsponsored work have no cash grant. Foreign-trader patrol arrivals now have an explicit 8,000 Cr fee.

Primary references inspected:

- [Published native X4 9.00 scripts and UI source](https://github.com/ArtByunex/x4-foundation-artbyunex/tree/e3e8a345e5624db118bff3eb171b60b0993fcc2c): target monitor panel metadata, UserQuestionMenu native confirmation, InteractMenu action/submenu contracts, NPC state machine.
- Extracted native `rml_hack_object.xml`: `find_room hascontrolpanel`; NPC state machine: `npc_move_to`, actor slots and existing service/marine roles; native NPC tool scripts: `pda1hand`; native `order.*` scripts: supported parameter types and finite orders.
- Documented command metadata in `tools/api_contracts.json`, with source file/line provenance. Added commands are checked against that metadata; matching installed XSD and expression-parser validation is unavailable.

These sources establish the exposed interfaces, not their success with the user's save/mod load order. See `HACKER_REVIEW_0.3.0.md` for the exact log evidence and limitations, and `TESTING.md` for unperformed in-game acceptance tests.
