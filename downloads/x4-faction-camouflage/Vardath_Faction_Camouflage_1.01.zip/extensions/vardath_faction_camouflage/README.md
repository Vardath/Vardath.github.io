# Vardath Faction Camouflage 1.01

A separate, save-compatible utility for **Hyperion Ascendant** and **Astrid Tours** only.

## Usage

1. Ensure **Mod Support APIs** is installed/enabled (the `sn_mod_support_apis` extension; Workshop ID `ws_2042901274`).
2. Right-click your owned Hyperion Ascendant or Astrid Tours ship on the map.
3. Choose **Select faction camouflage...** and click the desired faction. Available ship-owning factions are discovered dynamically, with a supplemental list of core factions.
4. To return to your true identity, right-click the same ship and select **Drop faction camouflage**, or choose **Use my real faction** in the selection window.

## Native disguise consequences

The mod calls Egosoft's `md.Cover.TriggerCover` using the selected faction. It does not alter real ship ownership, player faction reputation, relation boosts, missions, or combat scripts; it does not reapply a disguise after the engine exposes the ship. Native scans, attacks, combat exposure, player-enter/leave rules and reputation effects remain effective. **Do not expect a reputation guarantee during combat.**

## Safe scope

This does not modify either original ship extension. It does not change cargo, crew, ship loadouts, missiles, drones, jobs, turrets, orders, or the vanilla protected UI files. It uses Mod Support APIs' supported context-action and menu interfaces. Removing this mod will remove its extra menu commands; any cover already enabled is managed by X4's core Cover system.

## Acceptance checks (in X4, not covered by source validation)

- Right-click both ships separately, select a faction, and verify the visible faction identity without changing true ownership.
- Re-open the menu and drop disguise with one click; verify the original player identity returns.
- Verify a controlled ship and a remotely piloted ship, then save/reload.
- In a disposable test save, check combat exposure and reputation changes against vanilla Moreya behaviour. Native visibility and reputation cannot be guaranteed by source inspection.
- Ensure existing ship orders, other mods, and default map controls remain untouched.
