# Current release — 16 November 2026

1.0.11: Publishes the local Inventory Collector, Emergent Missions and Station Acquisition fixes from 1.0.10. This extension has no dependency on other Vardath mods. Repairs to third-party stale patch files are distributed separately as the 2026-11-16 compatibility repair bundle, because those files belong to the affected mods themselves.

Validated statically; restart X4 after installation. A fresh gameplay log is still needed for runtime confirmation.

## Earlier release notes

# Vardath Compatibility Fixes 1.0.6

**CI source coverage notice (1.0.6):** The release ZIP and 11 XML diffs are source-checked and 19 contract tests are run, with two GalaxyTrader tests skipped because the previous pinned upstream GitHub URLs now return HTTP 404. The two unchanged GalaxyTrader patches remain packaged but their application to the installed game build is not revalidated. The CI workflow is green with a deliberately recorded `result: partial`; this does not mean complete upstream or in-game validation.


Thirteen targeted XML compatibility patches. Version 1.0.6 additionally guards the `Bounties_UpdateLastKnown` Kuertee library against computer-class pseudo-pilots and initialises missing saved pilot/faction history lists before native tracking runs. Existing entries and reward calculations are not cleared. Version 1.0.5 adds source-matched Kuertee bounty null-pilot and NPC target-selection guards, plus skips Fly-by Looting ammunition pickup on M/L/XL ships after repeated M-class Verdandi rejection. S-class compatible ammo and other loot collection remain untouched. Earlier versions: 1.0.4 makes four Terran Cadet Chapter 2 long-range-scan yellow help panels dismissible when input progress stalls, retaining all DLC storyline/scan conditions.  1.0.3 extends the Fly-by Looting ammo condition to exclude large capital-class ships that reject native collect_drop for X4 9.00. Install this folder under `extensions`, enable it and load your existing save. Keep Protected UI and Inventory Collector enabled.

Includes the GalaxyTrader destroyed-ship sector-name guard plus the original six guards and Inventory Collector's missing common-handler debug default, HeadHunter's absent-pilot expiry cleanup and Emergent Missions' late rescue callback. Native mission cleanup also takes a stable snapshot before invoking immediate callbacks that can change its source list.

No Lua/UI replacement, ship assets, reward replay, ownership transfer or forced player order cancellation. This extension does not require the new Hyperion. Third-party dependencies are optional and use the installed folder names recorded in the supplied log.

See `REVIEW_1.0.1.md` for current scope and live checks. `TESTING.md` documents the historical 1.0.0 review. Pinned source/mocked tests, native diff grammar and unique selector applications and archive/source checks pass. Terran scan input binding and in-game menu state are not changed or runtime tested. New engine paths are not tested in a running X4 instance.
